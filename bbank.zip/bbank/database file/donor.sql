-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2018 at 07:51 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donor`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `updationdate` varchar(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` int(15) NOT NULL,
  `securityquestion` varchar(30) NOT NULL,
  `answer` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `username`, `password`, `updationdate`, `address`, `email`, `mobile`, `securityquestion`, `answer`) VALUES
('1234', 'rti', '12345', '3-4-18', 'chhend', 'hhash', 11122, 'fav color', '46'),
('dsd', 'dsds', 'as', '2018-06-19 0', 'sddsds', 'dssdd', 112233, 'dss', 'ssdd');

-- --------------------------------------------------------

--
-- Table structure for table `bloodcollection`
--

CREATE TABLE `bloodcollection` (
  `empid` int(20) NOT NULL,
  `empname` varchar(50) NOT NULL,
  `no_of_bloodcollection` int(100) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodcollection`
--

INSERT INTO `bloodcollection` (`empid`, `empname`, `no_of_bloodcollection`, `date`) VALUES
(1, 'himanshu', 5, '06/05/2018'),
(2, 'varsha', 7, '06/05/2018');

-- --------------------------------------------------------

--
-- Table structure for table `bloodstore`
--

CREATE TABLE `bloodstore` (
  `serialno` int(11) NOT NULL,
  `bloodgroup` varchar(50) NOT NULL,
  `totalnoofblood` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodstore`
--

INSERT INTO `bloodstore` (`serialno`, `bloodgroup`, `totalnoofblood`) VALUES
(1, 'A-', 5),
(2, 'A+', 66),
(3, 'AB-', 53),
(4, 'AB+', 5),
(5, 'O-', 5),
(6, 'O+', 5),
(7, 'B+', 5),
(8, 'B-', 5);

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE `donors` (
  `id` varchar(11) NOT NULL,
  `password` varchar(20) NOT NULL,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `blood_type` varchar(20) NOT NULL,
  `diseases` varchar(100) NOT NULL,
  `bday` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `donation_date` varchar(11) NOT NULL,
  `temp` int(10) NOT NULL,
  `bp` varchar(10) NOT NULL,
  `weight` int(11) NOT NULL,
  `mobile` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `password`, `fname`, `lname`, `sex`, `blood_type`, `diseases`, `bday`, `address`, `city`, `donation_date`, `temp`, `bp`, `weight`, `mobile`) VALUES
('12345566666', 'dds', 'dsds', 'dsds', 'male', 'dd', 'dsds', '0018-02-12', 'sdsd', 'xxd', '4.6.18', 30, '90', 65, 2147483647),
('2', '12344', 'tom', 'clent', 'male', 'ab+', 'ds', '6-9-90', 'dddde', 'sssd', '4-5-18', 45, '78', 40, 123439);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `empid` int(11) NOT NULL,
  `f_name` varchar(35) NOT NULL,
  `m_name` varchar(15) NOT NULL,
  `l_name` varchar(35) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `b_day` varchar(20) NOT NULL,
  `designation` varchar(35) NOT NULL,
  `mobile_nr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`empid`, `f_name`, `m_name`, `l_name`, `username`, `password`, `b_day`, `designation`, `mobile_nr`) VALUES
(11, 'dds', 'sdds', 'zd', 'ds', '1233', 'dsfsd', 'sdd', 12345678);

-- --------------------------------------------------------

--
-- Table structure for table `requestblood`
--

CREATE TABLE `requestblood` (
  `patientname` varchar(20) NOT NULL,
  `hospitalname` varchar(50) NOT NULL,
  `bloodgroup` varchar(10) NOT NULL,
  `date` varchar(56) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requestblood`
--

INSERT INTO `requestblood` (`patientname`, `hospitalname`, `bloodgroup`, `date`, `address`) VALUES
('qw', 'qqqqq', 'A-', '0000-00-00 00:00:00.000000', 'chhend'),
('', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` varchar(11) NOT NULL,
  `password` varchar(30) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `blood_type` varchar(10) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(100) NOT NULL,
  `mobile` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `password`, `first_name`, `last_name`, `email`, `dob`, `gender`, `blood_type`, `address`, `city`, `mobile`) VALUES
('0', 'varsha690', 'varsha', 'rani', 'varshakumari690@gmail.com', '3/07/1993', 'female', 'a+', 'dtg', 'dtg', '9546685973'),
('1234', 'wede', 'kjk', 'klk', 'lklk', 'lklk', 'male', 'mnk', 'mkm', 'kmk', 'kmk'),
('123678', '123', 'yyy', 'yyy', 'aaa', '8789', 'gyg', 'hh', 'hh', 'hh', '76767'),
('2147483647', '9122', 'himanshu', 'sahoo', 'hsahoo204@gmail.com', '9/8/2018', 'male', 'b+', 'chhend', 'roukela', '9040902234'),
('56565', 'HUJ', 'JH', 'HH', 'J', 'JJ', 'male', 'a+', 'NNJN', 'BHJG', '9040902234'),
('777', 'hyh', 'hhy', 'hygy', 'gyg', 'gy', 'male', 'jkj', 'kjk', 'jkj', '9546685973'),
('9898', 'JJUHU', 'HUH', 'HUH', 'HU', 'HU', 'male', 'GYH', 'HUH', 'UHUH', '68768686'),
('sdfsdd', 'dsddsdsd', 'dssdsd', 'dssd', 'ssdd', '0011-11-11', 'male', 'ab+', 'dtg', 'roukela', '23222');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `bloodcollection`
--
ALTER TABLE `bloodcollection`
  ADD PRIMARY KEY (`empid`),
  ADD UNIQUE KEY `empname` (`empname`);

--
-- Indexes for table `bloodstore`
--
ALTER TABLE `bloodstore`
  ADD PRIMARY KEY (`serialno`);

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`empid`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `user_id` (`empid`),
  ADD UNIQUE KEY `username_2` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `userid` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
