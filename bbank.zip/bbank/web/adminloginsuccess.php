<?php
include "admintop.php";
include"adminsuccesscontent.php";
include "footer.php";
?>