<?php
session_start();
include "db.php";
include "header.php";

$q=mysqli_query($con,"select * from admin where adminid='".$_SESSION['adminid']."'");
if($arr=mysqli_fetch_array($q))
{
	$adminid=$arr['adminid'];
	$username=$arr['username'];
	$securityquestion=$arr['securityquestion'];
	$answer=$arr['answer'];
}
?>

<center>
<h1>Profile details</h1>
<form method="post">
<table>
<tr><td>username</td><td><input type="text" value="<?php echo $username;?>"name="username"/></td></tr>
<tr><td>adminid</td><td><input type="text" value="<?php echo $adminid;?>"name="adminid"/></td></tr>


<tr><td>securityquestion</td><td><select name="securityquestion"><option>fav color</option><option>first teacher</option></select></td></tr>
<tr><td>answer</td><td><input type="text" name="answer" value="<?php echo $answer;?>"/></td></tr>
<tr><td></td><td><input type="submit" value="update" name="upbtn"/></td></tr>
<tr><td></td><td></td></tr>
</table>
</form>
</center>
<?php
if(isset($_POST['upbtn']))
{
	include "db.php";
	$username=$_POST['username'];
	$securityquestion=$_POST['securityquestion'];
	$answer=$_POST['answer'];
	mysqli_query($con,"update admin set username='".$username."',securityquestion='".$securityquestion."',answer='".$answer."' where adminid='".$_SESSION['adminid']."'");
}
?>
<?php include "footer.php";
?>
