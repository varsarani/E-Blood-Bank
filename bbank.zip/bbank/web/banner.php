<div class="bnr-btm-w3layouts" id="appoint">
		<div class="bnr-lft-agileits">
			<h3 class="subheading-agileits-w3layouts">Our services</h3>
			<ul>
				<li>
					<span class="fa fa-stethoscope" aria-hidden="true"></span>Blood Donation</li>
				<li>
					<span class="fa fa-user-md" aria-hidden="true"></span>Blood Collection</li>
				<li>
					<span class="fa fa-stethoscope" aria-hidden="true"></span>Online Blood  Delivery</li>
				<li>
					<span class="fa fa-user-md" aria-hidden="true"></span>Request For Bloods</li>
				<li>
					<span class="fa fa-stethoscope" aria-hidden="true"></span>Donors Screening</li>
			</ul>
		</div>
		<div class="bnr-rgt-w3-agile">
			<form action="#" method="post">
				<div class="inputs-w3ls one">
					<input type="text" name="Name" placeholder="Name" required="">
				</div>
				<div class="inputs-w3ls two">
					<input type="email" name="Email" placeholder="Email address" required="">
				</div>
				<div class="inputs-w3ls one">
					<input type="text" name="Number" placeholder="Number" required="">
				</div>
				<div class="inputs-w3ls two">
					<input id="datepicker" name="Text" type="text" placeholder="Pick-up Date" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}"
					    required="">
				</div>
				<div class="inputs-w3ls">
					<textarea name="Comments" placeholder="Message" required=""></textarea>
				</div>
				<input type="submit" value="Send">
				<div class="clearfix"> </div>
			</form>
		</div>
	</div>
	<!-- //Banner bottom -->
	<!--about-->
		<!--about-->
	<div class="about-w3layouts" id="about">
		<div class="container">
			<div class="tittle-agileinfo">
				<h2 class="title-w3">About Us</h2>
				<div class="about-top">
					<h3 class="subheading-agileits-w3layouts"><u>Welcome to our E-Blood Bank</u></h3>
					<p class="para-agileits-w3layouts">This is a non-profitable service motive circle of Youths purely devoted for the welfare of society.Encouraging and inspiring people to donate blood and providing fresh blood to the needy people without any cost is the real goal of this organization.We feel one day no one in this country will die in scarcity of blood.People in need of blood contact us(in case they fail to manage from their family,friend,relatives or blood bank).In such condition,we manage blood.donors from our online database,which itself is the countrys largest donor online database.We have more than 40 hundred donors registered.Since our registration in may 2018,we successfully have saved more than 30 hundreds lives and also brought  smiles at the faces of more than 35 hundred families throughout the country. </p>
				</div>
			</div>
			<div class="about-right">
				<h3 class="subheading-agileits-w3layouts sub-2">Features:</h3>
<br>Blood Collection Management</br>
<br>Blood Issue Management</br>
<br>Inventory Management</br>
<br>Stock Management</br>
<br>Camp Management</br>
<br>User and System Management</br>
				<p class="para-agileits-w3layouts"></p>
				<div class="button-w3layouts">
					<a href="#contact" class="scroll"></a>
				</div>
			</div>
			<div class="about-left-agileits">
				<div class="left-pos-img">
					<img src="images/b3.jpg" alt="">
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//about-->