<?php
if(isset($_POST["register"]))
{
	
	include "db.php";
	$empid=$_POST["empid"];
	$empname=$_POST["empname"];
	$no_of_bloodcollection=$_POST["no_of_bloodcollection"];
	$date=$_POST["date"];
	
	
	$sql="insert into bloodcollection values('".$empid."','".$empname."','".$no_of_bloodcollection."','".$date."')";
	if(mysqli_query($con,$sql))
	{
		//echo $sql;
		header("location:success.php");
	}
}
?>

<?php include "header.php";
 ?>

<center>
<h1>Register for bloodcollection</h1>
<form method="post">
	<table>
		<tr>
			<td>
				empid
			</td>
			<td>
				<input type="text" name="empid"/>
			</td>
		</tr>
		<tr>
			<td>
				empname
			</td>
			<td>
				<input type="text" name="empname"/>
			</td>
		</tr>
		<tr>
			<td>
				no_of_bloodcollection
			</td>
			<td>
				<input type="text" name="no_of_bloodcollection"/>
			</td>
		</tr>
		<tr>
			<td>
				date
			</td>
			<td>
				<input type="date" name="date"/>
			</td>
		</tr>
		<tr><td></td><td><input type="submit" value="register" name="register"/></td></tr>
	</table>
</form>
</center>
<?php include "footer.php"
?>
