<table border="1" width="100%">
	<tr><th> serialno</th> <th> bloodgroup</th> <th>totalnoofblood</th></tr>
	<?php
		include 'db.php';
		$result=mysqli_query($con,"select * from bloodstore");
		while ($arr=mysqli_fetch_assoc($result)):
	?>	
	<form action="manage.php">
		<tr>
			<td><?php echo $arr["serialno"];?></td>
			<td><?php echo $arr["bloodgroup"];?></td>
			<td><?php echo $arr["totalnoofblood"];?></td>
			<td>
				<input type="hidden" value="<?php echo $arr["serialno"];?>" name="serialno"></input>
				<input type="submit" value="delete" name="b1"></input>
				<input type="submit" value="edit" name="b1"></input>
			</td>
		</tr>
	</form>
	<?php
endwhile;
?>

</table>