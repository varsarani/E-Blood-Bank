<div class="agileits-contact" id="contact">
		<div class="w3_agileits-contact-left">
		</div>
		<div class="contact-right-w3l">
				

			<h5 class="title-w3">Contact Us </h5>
			<form action="#" method="post">
			
				<div class="input-w3ls w3ls-left">
					<input type="text" class="name" name="First Name" placeholder="First Name" required="">
				</div>
				<div class="input-w3ls w3ls-rght">
					<input type="text" class="name" name="Last Name" placeholder="Last Name" required="">
				</div>
				<div class="input-w3ls w3ls-left">
					<input type="email" class="name" name="Email" placeholder="Email" required="">
				</div>
				<div class="input-w3ls w3ls-rght">
					<input type="text" class="name" name="Subject" placeholder="Subject" required="">
				</div>
				<div class="input-w3ls">
					<textarea placeholder="Your Message" required=""></textarea>
				</div>
				<div class="input-w3ls">
					<input type="submit" value="Send Message">
				</div>


			</form>
		</div>
		<div class="clearfix"></div>
	</div>
	<!-- //contact -->