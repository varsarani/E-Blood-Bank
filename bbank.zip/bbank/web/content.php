<!--//about-->
	<!-- Features -->
	<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					Blood Donation
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<img src="images/b1.jpg" alt=" " class="img-responsive" />
					<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi
						consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur,
						vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.
						<i>" Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.</i>
					</p>
				</div>
			</div>
		</div>
	</div>
	<!-- //bootstrap-pop-up -->
	<!-- gallery -->
	<div class="gallery-w3layouts" id="portfolio">
		<div class="container-fluid">
			<h5 class="title-w3">Portfolio</h5>
			<div class="col-md-3 gallery-columns">
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g1.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g1.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
									<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g2.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g2.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
									<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-3 gallery-columns">
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g4.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g4.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
									<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g5.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g5.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
									<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-3 gallery-columns">
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g7.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g7.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
									<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g8.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g8.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
								<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-3 gallery-columns">
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g6.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g6.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
									<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="images/g3.jpg">
						<div class="gal_grid_outer1">
							<img src="images/g3.jpg" alt=" " class="img-responsive" />
							<div class="gallery_grid_pos">
								<h3>
									<span>B</span>lood
									<span>D</span>onation</h3>
							</div>
						</div>
					</a>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- //gallery -->
	
	<!-- testimonials -->
	<!-- contact -->
	<div class="agileits-contact" id="contact">
		<div class="w3_agileits-contact-left">
		</div>
		<div class="contact-right-w3l">

			<h5 class="title-w3">contact Us </h5>
			<form action="#" method="post">
				<div class="input-w3ls w3ls-left">
					<input type="text" class="name" name="First Name" placeholder="First Name" required="">
				</div>
				<div class="input-w3ls w3ls-rght">
					<input type="text" class="name" name="Last Name" placeholder="Last Name" required="">
				</div>
				<div class="input-w3ls w3ls-left">
					<input type="email" class="name" name="Email" placeholder="Email" required="">
				</div>
				<div class="input-w3ls w3ls-rght">
					<input type="text" class="name" name="Subject" placeholder="Subject" required="">
				</div>
				<div class="input-w3ls">
					<textarea placeholder="Your Message" required=""></textarea>
				</div>
				<div class="input-w3ls">
					<input type="submit" value="Send Message">
				</div>

			</form>
		</div>
		<div class="clearfix"></div>
	</div>
	