<?php
session_start();
include "db.php";
$q=mysqli_query($con,"select * from donors where id='".$_SESSION['id']."'");
if($arr=mysqli_fetch_array($q))
{
	$id=$arr['id'];
	$address=$arr['address'];
	$mobile=$arr['mobile'];
}
?>
<center>
<h1>Profile details</h1>
<form method="post">
<table>
<tr><td>id</td><td><input type="text" value="<?php echo $id;?>"name="id"/></td></tr>
<tr><td>address</td><td><input type="text" value="<?php echo $address;?>"name="address"placeholder="enter your address"/></td></tr>
<tr><td>mobile</td><td><input type="text" value="<?php echo $mobile;?>"name="mobile"/></td></tr>

<tr><td></td><td><input type="submit" value="update" name="upbtn"/></td></tr>
<tr><td></td><td></td></tr>
</table>
</form>
</center>
<?php
if(isset($_POST['upbtn']))
{
	include "db.php";
	$address=$_POST['address'];
	$mobile=$_POST['mobile'];
	
	mysqli_query($con,"update donors set address='".$address."',mobile='".$mobile."' where id='".$_SESSION['id']."'");
}
?>
