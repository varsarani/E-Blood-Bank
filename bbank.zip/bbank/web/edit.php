<?php
	//$id=$_SESSION["id"];
	$serialno=$_REQUEST["serialno"];
	include 'db.php';
	/*if(isset($_REQUEST["b1"]))
	{
		$answer=$_REQUEST["answer"];
		mysqli_query($con,"update donors set answer='$answer' where id='$id'");
		header('location:viewuser.php');
	}*/
	if(isset($_REQUEST['upbtn']))

{
	include"db.php";
	$totalnoofblood=$_REQUEST['tnbg'];
	$s=mysqli_query($con,"update bloodstore set totalnoofblood='$totalnoofblood' where serialno='$serialno'");
	if(isset($s))
	{
	header('location:managebloodlist.php');
	}

}	
	$result=mysqli_query($con,"select * from bloodstore where serialno='$serialno'");
	$arr=mysqli_fetch_assoc($result);
?>
<form>
<table>
	<tr>
		<th>
			serial No
		</th>
		<th>
			Blood Group
			</th>
			<th>
				Total no of blood
			</th>
	</tr>
	<tr>
		<td>
		Sl no:<?php echo $arr["serialno"];?>
		</td>
		<td>
			Blood Group:<?php echo $arr["bloodgroup"];?>
		</td>
		<td>
			Total no of blood group:<input value="<?php echo $arr["totalnoofblood"];?>" name="tnbg">
		</td>
	</tr>
	<tr>
		<td>
			<input type="hidden" value="<?php echo $arr["serialno"];?>" name="serialno"/>
			<input type="submit" value="update" name="upbtn"/>
		</td>
	</tr>
</table>
	
	
	
	<tr><td></td><td>
	<br/>
	
</form>
