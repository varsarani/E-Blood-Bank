<div id="templatemo_content">
<h1>Thank you for registration</h1>
<a href="employeelogin.php">login here</a>
</div>