
<html lang="zxx">
<head>
	<title>Pearly Care Medical Category Bootstrap responsive Website Template | Home :: w3layouts</title>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Pearly Care Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta Tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<link rel="stylesheet" href="css/jquery-ui.css" />
	<link href="css/simpleLightbox.css" rel="stylesheet" type="text/css" />
	<link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!--Online-fonts-->
	<link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
	<!--//Online-fonts-->
</head>

<body>
	<!-- Header -->
	<div class="logo-w3layouts">
		<div class="header-top-w3ls">
			<div class="container">
				<div class="w3l-social">
					<ul>
						<li>
							<a href="#" class="fa fa-facebook"></a>
						</li>
						<li>
							<a href="#" class="fa fa-twitter"></a>
						</li>
						<li>
							<a href="#" class="fa fa-google-plus"></a>
						</li>
					</ul>
				</div>
				<div class="right-p">
					<ul>
						<li>
							<span class="fa fa-phone" aria-hidden="true"></span>09546685973</li>
						<li>
							<span class="fa fa-clock-o" aria-hidden="true"></span>( Mon-Fri 9am - 8pm ) ( Sat-Sun 10am - 6pm )</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="header-mid">
			<div class="container">
				<h1>
					<a href="index.php">
					<span>E-</span>
						<span>B</span>lood
						<span>D</span>onation</a>
				</h1>
				<div class="w3ls_search">
					<div class="cd-main-header">
						<ul class="cd-header-buttons">
							<li>
								<a class="cd-search-trigger" href="#cd-search">
									<span></span>
								</a>
							</li>
						</ul>
						<!-- cd-header-buttons -->
					</div>
					<div id="cd-search" class="cd-search">
						<form action="#" method="post">
							<input name="Search" type="search" placeholder="Click enter after typing...">
						</form>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
