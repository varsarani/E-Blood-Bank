<table border="2"align="center"width="100%">
<tr><th>id</th>
<th>fname</th>
<th>lname</th>
<th>sex</th>
<th>blood_type</th>
<th>diseases</th>
<th>bday</th>
<th>address</th>
<th>city</th>
<th>donation_date</th>
<th>temp</th>
<th>bp</th>
<th>weight</th>
<th>mobile</th>
</tr>
<?php
include 'db.php';
$sql=mysqli_query($con,"select * from donors");
while (($arr=mysqli_fetch_assoc($sql))):
	?>

<form action="manage1.php">
	<tr>
	<td><?php echo $arr["id"];?></td>
	<td><?php echo $arr["fname"];?></td>
	<td><?php echo $arr["lname"];?></td>
	<td><?php echo $arr["sex"];?></td>
	<td><?php echo $arr["blood_type"];?></td>
	<td><?php echo $arr["diseases"];?></td>
	<td><?php echo $arr["bday"];?></td>
	<td><?php echo $arr["address"];?></td>
	<td><?php echo $arr["city"];?></td>
	<td><?php echo $arr["donation_date"];?></td>
	<td><?php echo $arr["temp"];?></td>
	<td><?php echo $arr["bp"];?></td>
	<td><?php echo $arr["weight"];?></td>
	<td><?php echo $arr["mobile"];?></td>
 <td>
				<input type="hidden" value="<?php echo $arr["id"];?>" name="id"></input>
				<input type="submit" value="delete" name="b1"></input>
				<input type="submit" value="edit" name="b1"></input>
			</td>

	</tr>
	</form>
	<?php
	endwhile;
	?>

    

