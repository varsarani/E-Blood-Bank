<?php
//include "top.php";
//include "banner.php";
include "registercontent.php";
include "footer.php";
?>
