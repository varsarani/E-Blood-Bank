<?php
include "top.php";
include "banner.php";
include "content.php";
include "servicecontent.php";
include "footer.php";
?>