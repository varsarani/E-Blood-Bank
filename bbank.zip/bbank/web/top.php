
<html lang="zxx">
<head>
	<title>E-Blood Bank| Home :: w3layouts</title>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Pearly Care Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta Tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<link rel="stylesheet" href="css/jquery-ui.css" />
	<link href="css/simpleLightbox.css" rel="stylesheet" type="text/css" />
	<link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!--Online-fonts-->
	<link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
	<!--//Online-fonts-->
</head>

<body>
	<!-- Header -->
	<div class="logo-w3layouts">
		<div class="header-top-w3ls">
			<div class="container">
				<div class="w3l-social">
					<ul>
						<li>
							<a href="#" class="fa fa-facebook"></a>
						</li>
						<li>
							<a href="#" class="fa fa-twitter"></a>
						</li>
						<li>
							<a href="#" class="fa fa-google-plus"></a>
						</li>
					</ul>
				</div>
				<div class="right-p">
					<ul>
						<li>
							<span class="fa fa-phone" aria-hidden="true"></span>07504059620</li>
						<li>
							<span class="fa fa-clock-o" aria-hidden="true"></span>( Mon-Fri 9am - 8pm ) ( Sat-Sun 10am - 6pm )</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="header-mid">
			<div class="container">
				<h1>
					<a href="index.php">
					<span>E-</span>
						<span>B</span>lood
						<span>D</span>onation</a>
				</h1>
				<div class="w3ls_search">
					<div class="cd-main-header">
						<ul class="cd-header-buttons">
							<li>
								<a class="cd-search-trigger" href="#cd-search">
									<span></span>
								</a>
							</li>
						</ul>
						<!-- cd-header-buttons -->
					</div>
					<div id="cd-search" class="cd-search">
						<form action="#" method="post">
							<input name="Search" type="search" placeholder="Click enter after typing...">
						</form>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- banner-slider -->
	<div class="w3l_banner_info" id="home">
		<div class="slider">
			<div class="callbacks_container">
				<!-- Navigation -->
				<div class="header-nav">
					<div class="container">
						<nav class="navbar navbar-default">
							<div class="navbar-header logo">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div>
							<!-- navbar-header -->
							<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
								<ul class="nav navbar-nav navbar-right">
									<li>
										<li class="nav-item">
										<a class="scroll"href="index.php">Home</a>
									</li>
									<li class="nav-item">
									  <a href="contactus.php" class="scroll">Contact Us</a>
									  </li>
									  <li class="nav-item">
									  <a href="service.php" class="scroll">Service</a>
									  </li>
									  <li class="nav-item">
									  <a href="bloodlist.php" class="nav-link">Blood List</a>
									  </li>
									   <li class="nav-item">
									  <a href="register.php" class="nav-link">Registration</a>
									  </li>
									   <li class="nav-item">
									  <a href="login.php" class="nav-link">Login</a>
									  </li>
									   <li class="nav-item">
									  <a href="requestblood.php" class="nav-link">RequestBlood</a>
									  </li>
							</div>
							<div class="clearfix"> </div>
						</nav>
						<div class="clearfix"> </div>
					</div>
				</div>
				<!-- //Navigation -->
				<ul class="rslides" id="slider3">
					<li>
						<div class="slider-img b1">
						</div>
						<div class="slider_banner_info">
							<div class="w3ls-info">
								<h4>
									<span>B</span>lood
									<span>D</span>onation</h4>
								<p>We can improve your health.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="slider-img b2">
						</div>
						<div class="slider_banner_info">
							
						</div>
					</li>
					<li>
						<div class="slider-img b3">
						</div>
						<div class="slider_banner_info">
							
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>