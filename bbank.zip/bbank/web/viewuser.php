<table border="1" width="100%">
	<tr><th> empid</th> <th> empname</th> <th>no_of_bloodcollection</th><th>date</th></tr>
	<?php
		include 'db.php';
		$result=mysqli_query($con,"select * from bloodcollection");
		while ($arr=mysqli_fetch_assoc($result)):
	?>	
	<form action="manage.php">
		<tr>
			<td><?php echo $arr["empid"];?></td>
			<td><?php echo $arr["empname"];?></td>
			<td><?php echo $arr["no_of_bloodcollection"];?></td>
			<td><?php echo $arr["date"];?></td>
			<td>
				<input type="hidden" value="<?php echo $arr["empid"];?>" name="empid"></input>
				<input type="submit" value="delete" name="b1"></input>
				<input type="submit" value="edit" name="b1"></input>
			</td>
		</tr>
	</form>
	<?php
endwhile;
?>

</table>